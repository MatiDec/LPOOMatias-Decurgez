import java.util.List;

public class Camara {
    private float x, y;
    private final float anchoVentana, altoVentana;
    private float objetivoX, objetivoY; 
    private float zoomFactor;  

    public Camara(float x, float y, float anchoVentana, float altoVentana) {
        this.x = x;
        this.y = y;
        this.anchoVentana = anchoVentana;
        this.altoVentana = altoVentana;
        this.objetivoX = x;  
        this.objetivoY = y;
        this.zoomFactor = 1.0f;  
    }


    public void setZoomFactor(float zoomFactor) {
        this.zoomFactor = zoomFactor;
    }


    public float getZoomFactor() {
        return zoomFactor;
    }

    public void actualizar(Jugador jugador, List<Bloque> bloquesCamara) {
        Bloque bloqueMasCercano = obtenerBloqueMasCercano(jugador, bloquesCamara);

        if (bloqueMasCercano != null) {

            objetivoX = bloqueMasCercano.x * 32 - (anchoVentana / 2); 
            objetivoY = bloqueMasCercano.y * 32 - (altoVentana / 2); 
        } else {
        
            objetivoX = jugador.getX() - (anchoVentana / 2);  
            objetivoY = jugador.getY() - (altoVentana / 2);  
        }

        float suavidad = 0.05f;  
        x += (objetivoX - x) * suavidad;
        y += (objetivoY - y) * suavidad;
    }

    private Bloque obtenerBloqueMasCercano(Jugador jugador, List<Bloque> bloquesCamara) {
        Bloque bloqueMasCercano = null;
        float distanciaMinima = Float.MAX_VALUE;

        for (Bloque bloque : bloquesCamara) {
            float distancia = (float) Math.sqrt(Math.pow(jugador.getX() - (bloque.x * 32), 2) + 
                                                Math.pow(jugador.getY() - (bloque.y * 32), 2));
            if (distancia < distanciaMinima) {
                distanciaMinima = distancia;
                bloqueMasCercano = bloque;
            }
        }

        return bloqueMasCercano;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }
}
