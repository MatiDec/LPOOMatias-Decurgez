import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.IOException;


public class Ventana extends JFrame {
    private static final long serialVersionUID = 1L;
    private int nivelAnterior = 1;
    private final int ancho = 1280;
    private final int alto = 720;

    private BufferedImage background;
    private JPanel panelJuego;
    public JPanel panelMenu;
    private Camara camara;
    private Timer timer;
    private Timer timer2;
    private int vidas;
    private Niveles nivel;
    private Jugador jugador;
    public JPanel panelPause;
    private Timer timerVictoria;
    private JLabel contadorVidas = new JLabel();
    private ImageIcon vidaIcon3, vidaIcon2, vidaIcon1;
    public boolean enPausa = false;
    private GameOverPanel gameOverPanel;
    private JPanel panelVictoria;
    private final float ZOOM_SCALE = 1.5f;
    
    
    public Ventana(Jugador jugador, Niveles nivel) {
        this.jugador = jugador;
        this.nivel = nivel;
        nivel.nivelactual = 0;
        
        panelPause = new panelPause(this); 
        panelPause.setVisible(false);
        
        setTitle("Anima Perpetua");
        setSize(ancho, alto);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(new BorderLayout());

    
        camara = new Camara((float) (jugador.getX()/ZOOM_SCALE), (float) (jugador.getY()/ZOOM_SCALE), 
                (int)(ancho/ZOOM_SCALE), (int)(alto/ZOOM_SCALE));
        camara.actualizar(jugador, nivel.bloquesCamara); 
        gameOverPanel = new GameOverPanel(this);
        panelJuego = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;

                // Guardamos la transformación original para restablecerla después
                AffineTransform originalTransform = g2d.getTransform();

                // Dibujamos el fondo
                dibujarFondo(g);

                // Aplicamos el zoom (escala) sobre el área de juego
                g2d.scale(ZOOM_SCALE, ZOOM_SCALE);

                // Calculamos el offset dinámicamente dependiendo de la escala y el tamaño de la ventana
                int offsetX = (getWidth() - ancho) / 2;
                int offsetY = (getHeight() - alto) / 2;

                // Aplicamos el offset calculado para centrar el contenido
                g2d.translate(offsetX / ZOOM_SCALE, offsetY / ZOOM_SCALE);

                // Dibujamos el nivel y al jugador
                nivel.dibujar(g, camara);
                jugador.dibujar(g, camara);

                // Restauramos la transformación original para no afectar otros componentes
                g2d.setTransform(originalTransform);

                // Si el contador de vidas no es null, lo mostramos ajustado a la escala
                if (contadorVidas != null) {
                    contadorVidas.setLocation((int) (40 * ZOOM_SCALE), (int) (10 * ZOOM_SCALE));
                }
            }



        };
        cargarIconosDeVidas();  
        contadorVidas.setBounds(40, 10, 200, 90);
        actualizarContadorVidas();
        panelJuego.add(contadorVidas);

        panelMenu = new JPanel()
        {
			private static final long serialVersionUID = 1L;

			@Override
             protected void paintComponent(Graphics g) {
                 super.paintComponent(g);

                 dibujarFondo(g);
             }
        };
        panelMenu.setLayout(null);
        
        cargarFondos();
        
        
        ImageIcon tituloImagen = new ImageIcon(getClass().getResource("/Texturas/menuinicio.png"));
        
        JLabel titulo = new JLabel();
        titulo.setBounds(0, 0, ancho, alto);
        
        Image imagenEscalada = tituloImagen.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        titulo.setIcon(new ImageIcon(imagenEscalada));        
        panelMenu.add(titulo);

        ImageIcon playImagen = new ImageIcon(getClass().getResource("/Texturas/Playbutton (2).png"));

	    imagenEscalada = playImagen.getImage().getScaledInstance(170, 50, Image.SCALE_SMOOTH);

	    JButton botonPlay = new JButton(new ImageIcon(imagenEscalada));
	    botonPlay.setBounds(570, 380, 170, 50);

	    botonPlay.setBorderPainted(false);
	    botonPlay.setContentAreaFilled(false);
	    botonPlay.setFocusPainted(false);

        botonPlay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarJuego();
            }
        });
        
        panelMenu.add(botonPlay);
        panelVictoria = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon victoryImage = new ImageIcon(getClass().getResource("/Texturas/WINSCREEN.PNG"));
                g.drawImage(victoryImage.getImage(), 0, 0, ancho-16, alto-38, this); 
            }

        };
        panelVictoria.setLayout(null);
        panelVictoria.setVisible(false);
        getContentPane().add(panelVictoria, BorderLayout.CENTER);

        timerVictoria = new Timer(15000, e -> volverAlMenu());
        timerVictoria.setRepeats(false);
    
        ImageIcon exitImagen = new ImageIcon(getClass().getResource("/Texturas/exitbutton.png"));

	
	    imagenEscalada = exitImagen.getImage().getScaledInstance(170, 50, Image.SCALE_SMOOTH);
	

	    JButton botonExit = new JButton(new ImageIcon(imagenEscalada));
	    botonExit.setBounds(570, 500, 170, 50);
	    
	
	    botonExit.setBorderPainted(false);
	    botonExit.setContentAreaFilled(false);
	    botonExit.setFocusPainted(false);

	    botonExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               System.exit(0);
            }
        });
        
        panelMenu.add(botonExit);
        
        
        panelJuego.setLayout(null);

       
      

        
  
        actualizarContadorVidas();


        panelJuego.add(contadorVidas);
        

        getContentPane().add(panelMenu, BorderLayout.CENTER);
        
        
        panelJuego.addKeyListener(jugador.getControladorTeclado());

        panelJuego.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                if (evt.getKeyCode() == KeyEvent.VK_ESCAPE) {
                    if (enPausa) {
                        reanudarJuego(); 
                    } else {
                        pausarJuego(); 
                    }
                }
            }
        });

        panelJuego.addKeyListener(jugador.getControladorTeclado());


        addKeyListener(jugador.getControladorTeclado());
        

       
        
        timer = new Timer(14, e -> {
            jugador.actualizar(nivel.getBloques(), nivel.getEnemigos(), nivel.getKillBlocks(), nivel.getAguas(), nivel.getBoss());

            for (Enemigo enemigo : nivel.getEnemigos()) {
                enemigo.actualizar(nivel.getBloques(), nivel.getKillBlocks(), jugador);
            }

            camara.actualizar(jugador, nivel.bloquesCamara);           
            nivel.actualizarEstalactitasYPiedras(jugador);
            if (nivel.nivelactual != nivelAnterior) {
               
                cargarFondos(); 
                nivelAnterior = nivel.nivelactual; 
            }
            
            Boss boss = nivel.getBoss();
            if (boss != null) {
                boss.actualizar(nivel.getBloques(), nivel.getKillBlocks(), nivel.getEnemigos(), jugador);
                

                if (boss.getVida() <= 0) { 
                    timer.stop(); 
                    panelVictoria.setVisible(true); 
                    panelJuego.setVisible(false); 
                    getContentPane().add(panelVictoria, BorderLayout.CENTER); 
                    revalidate();
                    repaint();
                    
                    timerVictoria.start(); 
                }
            }
            actualizarContadorVidas();
            panelJuego.repaint();
        });
        }
    
    private void cargarIconosDeVidas() {
        vidaIcon3 = new ImageIcon(getClass().getResource("/Texturas/3vidas.png"));
        vidaIcon2 = new ImageIcon(getClass().getResource("/Texturas/2vidas.png"));
        vidaIcon1 = new ImageIcon(getClass().getResource("/Texturas/1vida.png"));
    }
    
    private void actualizarContadorVidas() {
       vidas = jugador.getVidas();  
        switch (vidas) {
            case 3:
                contadorVidas.setIcon(vidaIcon3);
                break;
            case 2:
                contadorVidas.setIcon(vidaIcon2);
                break;
            case 1:
                contadorVidas.setIcon(vidaIcon1);
                break;
            default:
                contadorVidas.setIcon(vidaIcon3);
                if (vidas <= 0) {
                    perdio();  
                }
                break;
        }
    }
    
    private void iniciarJuego() {
        panelVictoria.setVisible(false);


        nivel.nivelactual = 1;
        jugador.reiniciar(); 
        nivel.cambiarNivel("level-1.txt");
    	nivel.reproducirAudioilimitado("Sonidos/C3E1.wav");
        jugador.x = nivel.getSpawnBlock().x * 32; 
        jugador.y = nivel.getSpawnBlock().y * 32;
        cargarFondos();

        panelMenu.setVisible(false);
        if (panelJuego.getParent() != null) {
            getContentPane().remove(panelJuego);
        }
        getContentPane().add(panelJuego, BorderLayout.CENTER);
        panelJuego.setVisible(true);
        revalidate();
        repaint();

        panelJuego.requestFocusInWindow();
        timer.start(); 
    }



    private void volverAlMenu() {
        timerVictoria.stop(); 
        panelVictoria.setVisible(false); 
        getContentPane().remove(panelVictoria); 
        panelMenu.setVisible(true); 
        getContentPane().add(panelMenu, BorderLayout.CENTER); 
        revalidate();
        repaint();
        nivel.nivelactual = 0; 
        cargarFondos(); 
        timer2.start();
    }


    private void cargarFondos() {
        try {
            if (nivel.nivelactual == 0 || panelMenu.isVisible()) {
                background = ImageIO.read(getClass().getResource("/Texturas/C3E1.png"));
            } else if(nivel.nivelactual == 1) {
                background = ImageIO.read(getClass().getResource("/Texturas/n1fondo1.png"));
            } else if(nivel.nivelactual == 2) {
                background = ImageIO.read(getClass().getResource("/Texturas/n2fondo1.png"));
            } else if(nivel.nivelactual == 3) {
                background = ImageIO.read(getClass().getResource("/Texturas/n3fondo1.png"));
            } else if(nivel.nivelactual == 4) {
                background = ImageIO.read(getClass().getResource("/Texturas/n4fondo1.png"));
            } else if(nivel.nivelactual == 5) {
                background = ImageIO.read(getClass().getResource("/Texturas/n5fondo1.png"));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void perdio() {
		nivel.detenerAudio();
        timer.stop();
        panelJuego.setVisible(false);
        gameOverPanel.setVisible(true);
        getContentPane().add(gameOverPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

 
    private void dibujarFondo(Graphics g) {
        if (background == null) return;
        
        // Calculamos la posición X del fondo basada en la posición del jugador
        // Dividimos por 32 para mantener la proporción con los bloques
        float backgroundX = -(jugador.getX() / 32);
        
        // Dibujamos el fondo con las dimensiones originales de la ventana
        g.drawImage(background, 
                    (int)backgroundX, 
                    0,
                    ancho,  // Usamos el ancho original de la ventana
                    alto,   // Usamos el alto original de la ventana
                    this);
        
        // Dibujamos una copia adicional del fondo para asegurar la continuidad
        g.drawImage(background, 
                    (int)backgroundX + ancho, 
                    0,
                    ancho,
                    alto,
                    this);
    }
   
    
  



    public void pausarJuego() {
        timer.stop(); 
        enPausa = true; 
        panelPause.setVisible(true); 
        getContentPane().remove(panelJuego); 
        getContentPane().add(panelPause, BorderLayout.CENTER); 
        revalidate();
        repaint();
        jugador.velocidadX = 0;
        jugador.izquierdaPresionada = false;
        jugador.derechaPresionada = false;
        panelPause.requestFocusInWindow();
    }

    public void reanudarJuego() {
        enPausa = false; 
        getContentPane().remove(panelPause); 
        getContentPane().add(panelJuego, BorderLayout.CENTER);
        panelPause.setVisible(false); 
        panelJuego.setVisible(true); 
        revalidate();
        repaint();
        panelJuego.requestFocusInWindow();  
        timer.start(); 
    }

    public void reiniciarGame() {
        jugador.reiniciar(); 
        cargarFondos();  
        nivel.cambiarNivel("level-1.txt");
        nivel.nivelactual = 1;
        jugador.x = (float) nivel.getSpawnBlock().getX() * 32;
        jugador.y = (float) nivel.getSpawnBlock().getY() * 32;
        getContentPane().remove(panelPause); 
        getContentPane().add(panelJuego, BorderLayout.CENTER);  
        gameOverPanel.setVisible(false);  
        panelPause.setVisible(false);  

        panelJuego.setVisible(true);  
        revalidate();  
        repaint();

        panelJuego.requestFocusInWindow(); 
        timer.start();  
    }

    public void reiniciarNivelActual() {
        cargarFondos();  
        nivel.reiniciarElementos();
        getContentPane().remove(panelPause); 
        getContentPane().add(panelJuego, BorderLayout.CENTER);  
        gameOverPanel.setVisible(false);  
        panelPause.setVisible(false);  
        jugador.x = nivel.getSpawnBlock().x * 32;
        jugador.y = nivel.getSpawnBlock().y * 32;
        panelJuego.setVisible(true);  
        revalidate();  
        repaint();

        panelJuego.requestFocusInWindow(); 
        timer.start();  
    }
    
    public static void main(String[] args) {
        Niveles nivel = new Niveles("level-1.txt");
        Bloque spawnBlock = nivel.getSpawnBlock();
        Jugador jugador = new Jugador(spawnBlock.x * 32, spawnBlock.y * 32, nivel); 
        if(spawnBlock != null)
        {
        jugador.x = spawnBlock.x * 32; 
        jugador.y = spawnBlock.y * 32;
   
        }
        
        SwingUtilities.invokeLater(() -> {
            Ventana ventana = new Ventana(jugador, nivel);
            ventana.setVisible(true);
            ventana.setLocationRelativeTo(null);
            ventana.setResizable(false);
        });
    }

	public int getAncho() {
		return ancho;
	}
	public int getAlto() {
		return alto;
	}
}
