/**
 * 
 */
/**
 * 
 */
module galagaga {
	requires java.desktop;
}