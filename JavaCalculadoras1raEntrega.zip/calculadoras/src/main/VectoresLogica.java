package main;

import gui.VectoresMain;

public class VectoresLogica {

	public static void main(String[] args) {
		VectoresMain ventanaprincipal = new VectoresMain();
		ventanaprincipal.setVisible(true);
	}
	public static void R2suma(double a, double b, double c, double d, double[] resultadosR2S)
	{
		resultadosR2S[0] = a + c;
		resultadosR2S[1] = b + d;
	}
	public static void R3suma(double a, double b, double c, double d, double E, double f, double[] resultadosR3S)
	{
		resultadosR3S[0] = a + d;
		resultadosR3S[1] = b + E;
		resultadosR3S[2] = c + f;
	}
	public static void R2resta(double a, double b, double c, double d, double[] resultadosR2R)
	{
		resultadosR2R[0] = a - c;
		resultadosR2R[1] = b - d;
	}
	public static void R3resta(double a, double b, double c, double d, double E, double f, double[] resultadosR3R)
	{
		resultadosR3R[0] = a - d;
		resultadosR3R[1] = b - E;
		resultadosR3R[2] = c - f;
	}
	public static void R2MultEscalar(double a, double b, int escalar, double[] resultadosR2ME)
	{
		resultadosR2ME[0] = a * escalar;
		resultadosR2ME[1] = b * escalar;
	}
	public static void R3MultEscalar(double a, double b, double c, int escalar, double[] resultadosR3ME)
	{
		resultadosR3ME[0] = a * escalar;
		resultadosR3ME[1] = b * escalar;
		resultadosR3ME[2] = c * escalar;
	}
	public static void R2ProdEscalar(double a, double b, double c, double d, double[] resultadosR2PE)
	{
		resultadosR2PE[0] = a * c;
		resultadosR2PE[1] = b * d;
	}
	public static void R3ProdEscalar(double a, double b, double c, double d, double E, double f, double[] resultadosR3PE)
	{
		resultadosR3PE[0] = a * d;
		resultadosR3PE[1] = b * E;
		resultadosR3PE[2] = c * f;
	}
	public static void R2ProdVectorial(double a, double b, double c, double d, double[] resultadoR2PV)
	{
		resultadoR2PV[0] = ((a * d) - (b * c));
	}
	public static void R3ProdVectorial(double a, double b, double c, double d, double E, double f, double[] resultadoR3PV)
	{
		resultadoR3PV[0] = ((b * f) + (a * E) + (d * c)) - ((b * d) + (c * E) + (f * a));
	}
}