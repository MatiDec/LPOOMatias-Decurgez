package main;
import gui.Calculador_a;
import gui.VentanaV2;
import gui.Panel;
import gui.VectoresMain;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class mainVentana extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	Calculador_a ventanaEstandar = new Calculador_a();
	VentanaV2 ventanaSistEcuaciones = new VentanaV2();
	Panel ventanaMatrices = new Panel();
	VectoresMain ventanaVectores = new VectoresMain();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainVentana frame = new mainVentana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainVentana() {
		ventanaEstandar.setVisible(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 750, 475);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panelTitulo = new JPanel();
		panelTitulo.setBounds(10, 11, 714, 80);
		contentPane.add(panelTitulo);
		panelTitulo.setLayout(null);
		
		JLabel lblTitulo = new JLabel("Calculadoras");
		lblTitulo.setBounds(10, 11, 694, 58);
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setFont(new Font("Tahoma", Font.PLAIN, 40));
		panelTitulo.add(lblTitulo);
		
		JPanel panelPrincipal = new JPanel();
		panelPrincipal.setBounds(10, 102, 714, 323);
		contentPane.add(panelPrincipal);
		panelPrincipal.setLayout(null);
		
		JPanel panelBotones = new JPanel();
		panelBotones.setBounds(10, 11, 694, 301);
		panelPrincipal.add(panelBotones);
		panelBotones.setLayout(new GridLayout(2, 2, 0, 0));
		
		JButton btnEstandar = new JButton("Estándar");
		btnEstandar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaEstandar.setVisible(true);
			}
		});
		btnEstandar.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panelBotones.add(btnEstandar);
		
		JButton btnVectores = new JButton("Vectores");
		btnVectores.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panelBotones.add(btnVectores);
		btnVectores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaVectores.setVisible(true);
			}
		});
		
		JButton btnMatrices = new JButton("Matrices");
		btnMatrices.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaMatrices.setVisible(true);
			}
		});
		btnMatrices.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panelBotones.add(btnMatrices);
		
		JButton btnSistemaEcuac = new JButton("Sistema de Ecuaciones");
		btnSistemaEcuac.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ventanaSistEcuaciones.setVisible(true);
			}
		});
		btnSistemaEcuac.setFont(new Font("Tahoma", Font.PLAIN, 20));
		panelBotones.add(btnSistemaEcuac);
	}
}
