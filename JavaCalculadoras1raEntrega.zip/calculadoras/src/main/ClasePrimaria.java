package main;
import gui.Panel;

public class ClasePrimaria {

	public static void main(String[] args) {
		new Panel().setVisible(true);
	}
	

}
