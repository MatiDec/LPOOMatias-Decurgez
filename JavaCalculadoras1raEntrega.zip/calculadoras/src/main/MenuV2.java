package main;

import gui.VentanaV2;

public class MenuV2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			presentarventana();
	}
	
	private static void presentarventana()
	{
		VentanaV2 miVentana =new VentanaV2();
		miVentana.setVisible(true);
	}
}