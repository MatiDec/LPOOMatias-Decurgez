package gui;

import java.awt.EventQueue;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JLabel;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.text.BadLocationException;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class Panel extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Panel frame = new Panel();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Panel() {
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 542, 543);

	    int x =0;
	    int y=0;
	    contentPane = new JPanel();
	    contentPane.setBackground(new Color(0, 0, 50)); 
	    contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	    setContentPane(contentPane);
	    contentPane.setLayout(null);

	  
	    int f = 3;
        int c = 3;

        int[][] matriz1 = new int[c][f];
        int[][] matriz2 = new int[c][f];

        for ( x = 0; x < c; x++) {
            for ( y = 0; y < f; y++) {
                matriz1[x][y] = 0;
            }
        }

        for ( x = 0; x < c; x++) {
            for ( y = 0; y < f; y++) {
                matriz2[x][y] = 0;
            }
        }
        
        JTextArea textArea = new JTextArea();
        textArea.setBounds(10, 11, 500, 110);
        contentPane.add(textArea);
        textArea.setEditable(false);
        textArea.setFont(new Font("Arial", Font.PLAIN, 30)); 
        textArea.setBackground(Color.WHITE); // Establecer el color de fondo del JTextArea
        textArea.setFocusable(false); // Deshabilitar el enfoque para evitar que se pueda hacer clic

		
        StringBuilder matrizString = new StringBuilder();
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz1[i][j]).append(" ");
            }
            matrizString.append("   "); 
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz2[i][j]).append(" ");
            }
            matrizString.append("\n"); 
        }
        textArea.setText(matrizString.toString());

        
		
		JButton botondel1 = new JButton("1");
		botondel1.setForeground(new Color(255, 255, 255));
		botondel1.setBounds(10, 180, 86, 75);
		contentPane.add(botondel1);	
		botondel1.setBackground(new Color(255, 128, 64));
		botondel1.setFont(new Font("Arial", Font.BOLD, 24));
		botondel1.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel1.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel1.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel1.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel1.setBackground(new Color(255, 128, 64)); }
		
		});
		
		
		botondel1.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 1;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 1;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});














		

		
		
		JButton botondel2 = new JButton("2");
		botondel2.setForeground(new Color(255, 255, 255));
		botondel2.setBounds(106, 180, 86, 75);
		contentPane.add(botondel2);
		botondel2.setBackground(new Color(255, 128, 64));
		botondel2.setFont(new Font("Arial", Font.BOLD, 24));
		botondel2.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel2.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel2.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel2.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel2.setBackground(new Color(255, 128, 64)); }		
		});
		
		
		botondel2.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 2;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 2;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		
		JButton botondel3 = new JButton("3");
		botondel3.setForeground(new Color(255, 255, 255));
		botondel3.setBounds(201, 180, 86, 75);
		contentPane.add(botondel3);
		botondel3.setBackground(new Color(255, 128, 64));
		botondel3.setFont(new Font("Arial", Font.BOLD, 24));
		botondel3.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel3.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel3.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel3.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel3.setBackground(new Color(255, 128, 64)); }		
		
		});
		
		
		botondel3.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 3;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 3;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton botondel4 = new JButton("4");
		botondel4.setForeground(new Color(255, 255, 255));
		botondel4.setBounds(10, 266, 86, 75);
		contentPane.add(botondel4);
		botondel4.setBackground(new Color(255, 128, 64));
		botondel4.setFont(new Font("Arial", Font.BOLD, 24));
		botondel4.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel4.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel4.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel4.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel4.setBackground(new Color(255, 128, 64)); }		
		});
		
		
		botondel4.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 4;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 4;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton botondel5 = new JButton("5");
		botondel5.setForeground(new Color(255, 255, 255));
		botondel5.setBounds(106, 266, 86, 75);
		contentPane.add(botondel5);
		botondel5.setBackground(new Color(255, 128, 64));
		botondel5.setFont(new Font("Arial", Font.BOLD, 24));
		botondel5.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel5.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel5.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel5.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel5.setBackground(new Color(255, 128, 64)); }		
			});
		
		
		botondel5.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 5;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] ==0 ) {
		                    matriz2[x][y] = 5;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton botondel6 = new JButton("6");
		botondel6.setForeground(new Color(255, 255, 255));
		botondel6.setBounds(201, 266, 86, 75);
		contentPane.add(botondel6);
		botondel6.setBackground(new Color(255, 128, 64));
		botondel6.setFont(new Font("Arial", Font.BOLD, 24));
		botondel6.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel6.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel6.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel6.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel6.setBackground(new Color(255, 128, 64)); }		
		});
		
		
		botondel6.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 6;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 6;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton botondel7 = new JButton("7");
		botondel7.setForeground(new Color(255, 255, 255));
		botondel7.setBounds(10, 352, 86, 75);
		contentPane.add(botondel7);
		botondel7.setBackground(new Color(255, 128, 64));
		botondel7.setFont(new Font("Arial", Font.BOLD, 24));
		botondel7.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel7.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel7.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel7.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel7.setBackground(new Color(255, 128, 64)); } 
		});
		
		
		botondel7.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 7;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 7;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton botondel8 = new JButton("8");
		botondel8.setForeground(new Color(255, 255, 255));
		botondel8.setBackground(new Color(255, 128, 64));
		botondel8.setBounds(106, 352, 86, 75);
		contentPane.add(botondel8);
		botondel8.setBackground(new Color(255, 128, 64));
		botondel8.setFont(new Font("Arial", Font.BOLD, 24));
		botondel8.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel8.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel8.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel8.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel8.setBackground(new Color(255, 128, 64)); }		
		});
		
		botondel8.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 8;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 8;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		
		JButton botondel9 = new JButton("9");
		botondel9.setForeground(new Color(255, 255, 255));
		botondel9.setBounds(201, 352, 86, 75);
		contentPane.add(botondel9);
		botondel9.setBackground(new Color(255, 128, 64));
		botondel9.setFont(new Font("Arial", Font.BOLD, 24));
		botondel9.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel9.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel9.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel9.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel9.setBackground(new Color(255, 128, 64)); }		
		});
		
		
		botondel9.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] == 0) {
		                    matriz1[x][y] = 9;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] == 0) {
		                    matriz2[x][y] = 9;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton botondel0 = new JButton("0");
		botondel0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		botondel0.setForeground(new Color(255, 255, 255));
		botondel0.setBounds(10, 438, 86, 75);
		contentPane.add(botondel0);
		botondel0.setBackground(new Color(255, 128, 64));
		botondel0.setFont(new Font("Arial", Font.BOLD, 24));
		botondel0.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { botondel0.setBackground(new Color(200, 100, 50)); }
		    @Override public void mouseExited(MouseEvent e) { botondel0.setBackground(new Color(255, 128, 64)); }
		    @Override public void mousePressed(MouseEvent e) { botondel0.setBackground(new Color(255, 255, 153)); } 
			@Override public void mouseReleased(MouseEvent e) { botondel0.setBackground(new Color(255, 128, 64)); } 
		});

		botondel0.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		        for (int x = 0; x < f; x++) {
		            for (int y = 0; y < c; y++) {
		                if (matriz1[x][y] != 0) {
		                    matriz1[x][y] = 0;
		                    
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    
		                    return;
		                } else if (matriz2[x][y] != 0) {
		                    matriz2[x][y] = 0;
		                    StringBuilder matrizString = new StringBuilder();
		                    for (int i = 0; i < f; i++) {
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz1[i][j]).append(" ");
		                        }
		                        matrizString.append("   ");
		                        for (int j = 0; j < c; j++) {
		                            matrizString.append(matriz2[i][j]).append(" ");
		                        }
		                        matrizString.append("\n");
		                    }
		                    textArea.setText(matrizString.toString());
		                    return;
		                }
		            }
		        }
		    }
		});

		
		
		JButton ce = new JButton("C");
		ce.setBounds(106, 438, 181, 75);
		contentPane.add(ce);
		ce.setForeground(new Color(255, 255, 255));
		ce.setFont(new Font("Arial", Font.BOLD, 30));
		ce.setBackground(new Color(255, 200, 8));
		ce.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { ce.setBackground(new Color(255, 190, 30)); }
		    @Override public void mouseExited(MouseEvent e) { ce.setBackground(new Color(255, 200, 8)); }
		});
		
		ce.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		for(int x = 0 ; x < f ; x ++)
		{
			for(int y = 0 ; y < c ; y ++)
			{
				matriz1[x][y]=0;
				matriz2[x][y]=0;
			}
		}
		StringBuilder matrizString = new StringBuilder();
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz1[i][j]).append(" ");
            }
            matrizString.append("   ");
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz2[i][j]).append(" ");
            }
            matrizString.append("\n");
        }
        textArea.setText(matrizString.toString());
		}
		});
	
		JButton incrementarx = new JButton("x++");
		
		incrementarx.setBounds(10, 132, 57, 37);
		contentPane.add(incrementarx);
		incrementarx.setFont(new Font("Arial", Font.BOLD, 12));
		incrementarx.setBackground(new Color(192, 192, 192));
		incrementarx.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { incrementarx.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { incrementarx.setBackground(new Color(192, 192, 192)); }
		});
		
		JButton incrementary = new JButton("y++");
		incrementary.setBounds(77, 132, 57, 37);
		contentPane.add(incrementary);
		incrementary.setFont(new Font("Arial", Font.BOLD, 14));
		incrementary.setBackground(new Color(192, 192, 192));
		incrementary.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { incrementary.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { incrementary.setBackground(new Color(192, 192, 192)); }
		});
		
		JButton disminuirx = new JButton("x--");
		disminuirx.setBounds(163, 132, 57, 37);
		contentPane.add(disminuirx);
		disminuirx.setFont(new Font("Arial", Font.BOLD, 15));
		disminuirx.setBackground(new Color(192, 192, 192));
		disminuirx.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { disminuirx.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { disminuirx.setBackground(new Color(192, 192, 192)); }
		});
		
		JButton disminuiry = new JButton("y--");
		disminuiry.setBounds(230, 132, 57, 37);
		contentPane.add(disminuiry);
		disminuiry.setFont(new Font("Arial", Font.BOLD, 15));
		disminuiry.setBackground(new Color(192, 192, 192));
		disminuiry.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { disminuiry.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { disminuiry.setBackground(new Color(192, 192, 192)); }
		});
		
		JButton suma = new JButton("+");
		suma.setBounds(453, 290, 57, 137);
		contentPane.add(suma);
		suma.setFont(new Font("Arial", Font.BOLD, 24));
		suma.setBackground(new Color(192, 192, 192));
		suma.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { suma.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { suma.setBackground(new Color(192, 192, 192)); }
		});
		suma.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		    	int[][] matriz3 = new int[c][f];
		for(int x = 0 ; x < f ; x ++)
		{
			for(int y = 0 ; y < c ; y ++)
			{
				matriz3[x][y]=matriz1[x][y]+matriz2[x][y];
			}
		}
		StringBuilder matrizString = new StringBuilder();
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz1[i][j]).append(" ");
            }
            matrizString.append("   ");
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz2[i][j]).append(" ");
            }
            
                matrizString.append("       ");
            
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz3[i][j]).append(" ");
            }
            matrizString.append("\n");
        }
        textArea.setText(matrizString.toString());
		}
		});
		
		JButton resta = new JButton("-");
		resta.setBounds(386, 290, 57, 137);
		contentPane.add(resta);
		resta.setFont(new Font("Arial", Font.BOLD, 35));
		resta.setBackground(new Color(192, 192, 192));
		resta.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { resta.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { resta.setBackground(new Color(192, 192, 192)); }
		});
		
		resta.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		    	int[][] matriz3 = new int[c][f];
		for(int x = 0 ; x < f ; x ++)
		{
			for(int y = 0 ; y < c ; y ++)
			{
				matriz3[x][y]=matriz1[x][y]-matriz2[x][y];
			}
		}
		StringBuilder matrizString = new StringBuilder();
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz1[i][j]).append(" ");
            }
            matrizString.append("   ");
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz2[i][j]).append(" ");
            }
            
                matrizString.append("       ");
            
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz3[i][j]).append(" ");
            }
            matrizString.append("\n");
        }
        textArea.setText(matrizString.toString());
		}
		});
		
		JButton multiplicar = new JButton("x");
		multiplicar.setBounds(386, 132, 124, 68);
		contentPane.add(multiplicar);
		multiplicar.setFont(new Font("Arial", Font.BOLD, 24));
		multiplicar.setBackground(new Color(192, 192, 192));
		multiplicar.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { multiplicar.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { multiplicar.setBackground(new Color(192, 192, 192)); }
		});
		multiplicar.addMouseListener(new MouseAdapter() {
		    @Override
		    public void mouseClicked(MouseEvent e) {
		    	int[][] matriz3 = new int[c][f];
		for(int x = 0 ; x < f ; x ++)
		{
			for(int y = 0 ; y < c ; y ++)
			{
				matriz3[x][y]+=matriz1[x][y]*matriz2[x][y];
			}
		}
		StringBuilder matrizString = new StringBuilder();
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz1[i][j]).append(" ");
            }
            matrizString.append("   ");
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz2[i][j]).append(" ");
            }
            
                matrizString.append("       ");
            
            for (int j = 0; j < c; j++) {
                matrizString.append(matriz3[i][j]).append(" ");
            }
            matrizString.append("\n");
        }
        textArea.setText(matrizString.toString());
		}
		});
		
		
		
		JButton dividir = new JButton("%");
		dividir.setBounds(386, 211, 124, 68);
		contentPane.add(dividir);
		dividir.setFont(new Font("Arial", Font.BOLD, 24));
		dividir.setBackground(new Color(192, 192, 192));
		dividir.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { dividir.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { dividir.setBackground(new Color(192, 192, 192)); }
		});
		
		JButton multesc = new JButton("(λ)");
		multesc.setBounds(319, 132, 57, 93);
		contentPane.add(multesc);
		multesc.setFont(new Font("Arial", Font.BOLD, 18));
		multesc.setBackground(new Color(192, 192, 192));
		multesc.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { multesc.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { multesc.setBackground(new Color(192, 192, 192)); }
		});
		
		
		JButton inversa = new JButton("Inv");
		inversa.setBounds(319, 230, 57, 98);
		contentPane.add(inversa);
		inversa.setFont(new Font("Arial", Font.BOLD, 16));
		inversa.setBackground(new Color(192, 192, 192));
		inversa.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { inversa.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { inversa.setBackground(new Color(192, 192, 192)); }
		});
		
		JButton determinante = new JButton("Det");
		determinante.setBounds(319, 334, 57, 93);
		contentPane.add(determinante);
		determinante.setFont(new Font("Arial", Font.BOLD, 13));
		determinante.setBackground(new Color(192, 192, 192));
		determinante.addMouseListener(new MouseAdapter() {
		    @Override public void mouseEntered(MouseEvent e) { determinante.setBackground(new Color(150, 150, 150)); }
		    @Override public void mouseExited(MouseEvent e) { determinante.setBackground(new Color(192, 192, 192)); }
		});
		
		JLabel cuadroalpedo = new JLabel(" CALCUMATRIX3000");
		cuadroalpedo.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 18));
		cuadroalpedo.setForeground(new Color(255, 255, 255));
		cuadroalpedo.setBackground(new Color(255, 0, 0));
		cuadroalpedo.setOpaque(true);
		Border border = BorderFactory.createLineBorder(Color.WHITE,3);
		cuadroalpedo.setBorder(border);
		cuadroalpedo.setBounds(319, 438, 193, 75);
		contentPane.add(cuadroalpedo);
		
		
	}
	
}

