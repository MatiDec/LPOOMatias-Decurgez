package gui;

import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JToolBar;
import javax.swing.BoxLayout;
import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.Box;
import javax.swing.JMenu;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.BorderLayout;
import javax.swing.JTable;

public class VentanaV2 extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	
// 	variables for equation 1:
	private JTextField textfield_coeficiente_de_x_e1;
	private JTextField textfield_coeficiente_de_y_e1;
	private JTextField textfield_coeficiente_de_ti_e1;
	
// 	variables for equation 2:
	private JTextField textfield_coeficiente_de_x_e2;
	private JTextField textfield_coeficiente_de_y_e2;
	private JTextField textfield_coeficiente_de_ti_e2;
	
// variables for other things (functions, buttons inputs,focus keeper,etc)	
	String numeroIngresado = null;
	String last_focus = null;
	int boton = 0;
	
	private final JPanel panel_2 = new JPanel();
	
	
	/**
	 * Create the frame.
	 */
	public VentanaV2() {
		
		// General panel
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 446);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 509, 26);
		contentPane.add(panel);
		panel.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		// Text in the top
		JLabel lblNewLabel = new JLabel("Sistema de ecuaciones");
		panel.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		
		// 1st panel
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 37, 509, 74);
		contentPane.add(panel_1);
		panel_1.setLayout(new GridLayout(0, 6, 0, 5));
		
		// First equation
		JLabel texto_e_1 = new JLabel("1 ecuación:");
		texto_e_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(texto_e_1);
		
		// Text fields, where the user is going to put the inputs 
		// X:
		textfield_coeficiente_de_x_e1 = new JTextField();
		textfield_coeficiente_de_x_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_x_e1.setColumns(2);
		panel_1.add(textfield_coeficiente_de_x_e1);
		
		textfield_coeficiente_de_x_e1.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent e) {
				last_focus = "xe1";
			}

			@Override
			public void focusLost(FocusEvent e) {
					//we replace the value of "last_focus" on the others text fields
			}
				
		});
		
		JLabel lblNewLabel_1 = new JLabel("X +");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_1);
		
		// Y:
		textfield_coeficiente_de_y_e1 = new JTextField();
		textfield_coeficiente_de_y_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_y_e1.setColumns(10);
		panel_1.add(textfield_coeficiente_de_y_e1);
		
		textfield_coeficiente_de_y_e1.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent e) {
				last_focus = "ye1";
			}

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
				
		});
		
		JLabel lblNewLabel_2 = new JLabel("Y =");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_2);
		
		// TI:
		textfield_coeficiente_de_ti_e1 = new JTextField();
		textfield_coeficiente_de_ti_e1.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_ti_e1.setColumns(10);
		panel_1.add(textfield_coeficiente_de_ti_e1);
		
		textfield_coeficiente_de_ti_e1.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent e) {
				last_focus = "tie1";
			}

			@Override
			public void focusLost(FocusEvent e) {
				// TODO Auto-generated method stub
				
			}
				
		});
		
		// Second equation
		JLabel lblNewLabel_3_1 = new JLabel("2 ecuación:");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_3_1);
		
		// Text fields, where the user is going to put the inputs 
		// X:
		textfield_coeficiente_de_x_e2 = new JTextField();
		textfield_coeficiente_de_x_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_x_e2.setColumns(10);
		panel_1.add(textfield_coeficiente_de_x_e2);
		
		textfield_coeficiente_de_x_e2.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent e) {
				last_focus = "xe2";
			}

			@Override
			public void focusLost(FocusEvent e) {
					//we replace the value of "last_focus" on the others text fields
			}
				
		});
		
		JLabel lblNewLabel_1_1 = new JLabel("X +");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_1_1);
		
		// Y:
		textfield_coeficiente_de_y_e2 = new JTextField();
		textfield_coeficiente_de_y_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_y_e2.setColumns(10);
		panel_1.add(textfield_coeficiente_de_y_e2);
		
		textfield_coeficiente_de_y_e2.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent e) {
				last_focus = "ye2";
			}

			@Override
			public void focusLost(FocusEvent e) {
					//we replace the value of "last_focus" on the others text fields
			}
				
		});
		
		JLabel lblNewLabel_2_1 = new JLabel("Y =");
		lblNewLabel_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(lblNewLabel_2_1);
		
		// TI:
		textfield_coeficiente_de_ti_e2 = new JTextField();
		textfield_coeficiente_de_ti_e2.setHorizontalAlignment(SwingConstants.RIGHT);
		textfield_coeficiente_de_ti_e2.setColumns(10);
		panel_1.add(textfield_coeficiente_de_ti_e2);
		
		textfield_coeficiente_de_ti_e2.addFocusListener(new FocusListener() {

			@Override
			public void focusGained(FocusEvent e) {
				last_focus = "tie2";
			}

			@Override
			public void focusLost(FocusEvent e) {
					//we replace the value of "last_focus" on the others text fields
			}
				
		});
		
		
		
		// 2nd panel
		// Buttons for 2x2 system equation calculator and 3x3
		panel_2.setBounds(0, 122, 509, 56);
		contentPane.add(panel_2);
		
		// 2x2:
		JButton btn2x2 = new JButton("2x2");
		btn2x2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_2.setLayout(new GridLayout(0, 2, 0, 0));
		panel_2.add(btn2x2);
		
		// 3x3:
		JButton btn3x3 = new JButton("3x3");
		btn3x3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_2.add(btn3x3);
		
		
		// 3rd panel
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 189, 341, 218);
		contentPane.add(panel_3);
		panel_3.setLayout(new GridLayout(0, 3, 0, 0));
		
		// Calculator buttons 1,2,3,4,5,6,7,8,9,0,+/-,.
		
		JButton btn7 = new JButton("7");
		btn7.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 7;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 8;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 9;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn9);
		
		JButton btn4 = new JButton("4");
		btn4.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 4;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 5;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 6;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn6);
		
		JButton btn1 = new JButton("1");
		btn1.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 1;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 2;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 3;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn3);
		
		JButton btnCambioSigno = new JButton("+/-");
		panel_3.add(btnCambioSigno);
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e) 
			{	
				boton = 0;
				funcionalidad_botones(boton, last_focus);
			}
		});
		panel_3.add(btn0);
		
		JButton btnDecimal = new JButton(".");
		panel_3.add(btnDecimal);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(351, 271, 148, 51);
		contentPane.add(panel_4);
		panel_4.setLayout(new GridLayout(0, 1, 0, 0));
		
		
		// 4rd panel:
		// Resolve button
		JButton btnResolver = new JButton("Resolver");
		panel_4.add(btnResolver);
		
		setTitle("Calculadora");
	}
	
	private void funcionalidad_botones(int boton, String lastFocus)
	{
		switch(boton)
		{
		case 0:
			focus_keeper(boton,lastFocus);
			break;
		case 1:
			focus_keeper(boton,lastFocus);
			break;
		case 2:
			focus_keeper(boton,lastFocus);
			break;
		case 3:
			focus_keeper(boton,lastFocus);
			break;
		case 4:
			focus_keeper(boton,lastFocus);
			break;		
		case 5:
			focus_keeper(boton,lastFocus);
			break;
		case 6:
			focus_keeper(boton,lastFocus);
			break;
		case 7:
			focus_keeper(boton,lastFocus);
			break;
		case 8:
			focus_keeper(boton,lastFocus);
			break;
		case 9:
			focus_keeper(boton,lastFocus);
			break;
		}
	}
	
	private void focus_keeper(int boton, String lastfocus)
	{
		switch(lastfocus)
		{
		case "xe1":
			 numeroIngresado = textfield_coeficiente_de_x_e1.getText() + boton;
			 textfield_coeficiente_de_x_e1.setText(numeroIngresado);
			break;
		case "ye1":
			numeroIngresado = textfield_coeficiente_de_y_e1.getText() + boton;
			textfield_coeficiente_de_y_e1.setText(numeroIngresado);
			break;
		case "tie1":
			numeroIngresado = textfield_coeficiente_de_ti_e1.getText() + boton;
			textfield_coeficiente_de_ti_e1.setText(numeroIngresado);
			break;
		case "xe2":
			numeroIngresado = textfield_coeficiente_de_x_e2.getText() + boton;
			textfield_coeficiente_de_x_e2.setText(numeroIngresado);
			break;
		case "ye2":
			numeroIngresado = textfield_coeficiente_de_y_e2.getText() + boton;
			textfield_coeficiente_de_y_e2.setText(numeroIngresado);
			break;
		case "tie2":
			numeroIngresado = textfield_coeficiente_de_ti_e2.getText() + boton;
			textfield_coeficiente_de_ti_e2.setText(numeroIngresado);
			break;
		}
	}
}