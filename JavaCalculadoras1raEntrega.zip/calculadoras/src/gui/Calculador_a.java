package gui;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;


public class Calculador_a extends JFrame 
{
    private static final long serialVersionUID = 1L;
    private JTextField pantalla;
    private JPanel panel;
    private List<String> historial;
    private int indiceHistorial;

    public Calculador_a() 
    {
        setTitle("Calculadora");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        historial = new ArrayList<>();
        indiceHistorial = -1;

        pantalla = new JTextField();
        pantalla.setFont(new Font("Arial", Font.PLAIN, 24));
        pantalla.addKeyListener(new KeyAdapter() 
        {
            public void keyTyped(KeyEvent e) 
            {
                char c = e.getKeyChar();
                if (!Character.isDigit(c) && c != '+' && c != '-' && c != '*' && c != '/' && c != '^' && c != '.' && c != '(' && c != ')' && c != '\b' && c != '\n') 
                {
                    e.consume();
                } 
                else if (c == '\n') 
                {
                    evaluarExpresionPantalla();
                    e.consume();
                }
            }

            public void keyPressed(KeyEvent e) 
            {
                if (e.getKeyCode() == KeyEvent.VK_UP) 
                {
                    navegarHistorial(-1);
                    e.consume();
                } 
                else if (e.getKeyCode() == KeyEvent.VK_DOWN) 
                {
                    navegarHistorial(1);
                    e.consume();
                }
            }
        });
        add(pantalla, BorderLayout.NORTH);

        panel = new JPanel();
        panel.setLayout(new GridLayout(7, 4, 10, 10));
        add(panel, BorderLayout.CENTER);

        agregarBotones();

        setVisible(true);
    }

    private void agregarBotones() 
    {

        agregarBoton("(", 24);
        agregarBoton(")", 24);
        agregarBoton("^", 24);
        agregarBoton("C", 24);

        agregarBoton("7", 24);
        agregarBoton("8", 24);
        agregarBoton("9", 24);
        agregarBoton("/", 24);

        agregarBoton("4", 24);
        agregarBoton("5", 24);
        agregarBoton("6", 24);
        agregarBoton("*", 24);

        agregarBoton("1", 24);
        agregarBoton("2", 24);
        agregarBoton("3", 24);
        agregarBoton("-", 24);

        agregarBoton("0", 24);
        agregarBoton(".", 24);
        agregarBoton("=", 24);
        agregarBoton("+", 24);

        agregarBoton("√", 24);
        agregarBoton("^2", 24);
        agregarBoton("^3", 24);
        agregarBoton("DEL", 24);
    }

    private void agregarBoton(String texto, int tamanoFuente) 
    {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.PLAIN, tamanoFuente));
        boton.addActionListener(new manejarBoton());
        panel.add(boton);
    }

    private class manejarBoton implements ActionListener 
    {
        public void actionPerformed(ActionEvent e) 
        {
            String comando = e.getActionCommand();

            switch (comando) 
            {
                case "=":
                    evaluarExpresionPantalla();
                    break;
                case "C":
                    pantalla.setText("");
                    break;
                case "DEL":
                    String textoActual = pantalla.getText();
                    if (!textoActual.isEmpty()) {
                        pantalla.setText(textoActual.substring(0, textoActual.length() - 1));
                    }
                    break;
                case "^2":
                    pantalla.setText(pantalla.getText() + "^2");
                    break;
                case "^3":
                    pantalla.setText(pantalla.getText() + "^3");
                    break;
                default:
                    pantalla.setText(pantalla.getText() + comando);
                    break;
            }
        }
    }

    private void evaluarExpresionPantalla() 
    {
        String expresion = pantalla.getText();
        if (!expresion.isEmpty()) 
        {
            try 
            {
                String resultado = evaluar(expresion);
                double resultadoNumerico = Double.parseDouble(resultado);
                
               
                if (resultadoNumerico == (int) resultadoNumerico) {
                    pantalla.setText(String.valueOf((int) resultadoNumerico)); 
                } else {
                    pantalla.setText(resultado); 
                }
                
                historial.add(expresion);
                indiceHistorial = historial.size();
            }
            catch (ArithmeticException ex) 
            {
                pantalla.setText("Error: División por 0");
            }
            catch (Exception ex) {
                pantalla.setText("Error");
            }
        }
    }


    private void navegarHistorial(int direccion) 
    {
        if (historial.isEmpty()) 
        {
            return;
        }
        indiceHistorial += direccion;
        if (indiceHistorial < 0) 
        {
            indiceHistorial = 0;
        } 
        else if (indiceHistorial >= historial.size()) 
        {
            indiceHistorial = historial.size() - 1;
        }
        pantalla.setText(historial.get(indiceHistorial));
    }

    private String evaluar(String expresion) 
    {
        return Double.toString(evaluarExpresion(expresion));
    }

    private double evaluarExpresion(String expresion) 
    {
        return evaluarExpresionPostfija(convertirAPostfija(expresion));
    }

    private double evaluarExpresionPostfija(List<String> terminos) 
    {
        Stack<Double> valores = new Stack<>();
        for (String valor : terminos) 
        {
            if (esNumero(valor)) 
            {
                valores.push(Double.parseDouble(valor));
            } 
            else 
            {
                double b = valores.pop();
                double a = valores.isEmpty() ? 0 : valores.pop();
                switch (valor) 
                {
                    case "+":
                        valores.push(a + b);
                        break;
                    case "-":
                        valores.push(a - b);
                        break;
                    case "*":
                        valores.push(a * b);
                        break;
                    case "/":
                        if (b != 0) 
                        {
                            valores.push(a / b);
                        } 
                        else 
                        {
                            throw new ArithmeticException("División por 0");
                        }
                        break;
                    case "^":
                        valores.push(Math.pow(a, b));
                        break;
                    case "√":
                        valores.push(Math.sqrt(b));
                        break;
                }
            }
        }
        return valores.pop();
    }

    private List<String> convertirAPostfija(String expresion) 
    {
    	int x;
        List<String> terminos = new ArrayList<>();
        Stack<Character> operadores = new Stack<>();
        StringBuilder numero = new StringBuilder();

        for (x = 0; x < expresion.length(); x++) 
        {
            char c = expresion.charAt(x);

            if (Character.isDigit(c) || c == '.') 
            {
                numero.append(c);
            } else {
                if (numero.length() > 0) 
                {
                    terminos.add(numero.toString());
                    numero.setLength(0);
                }

                if (c == '(') 
                {
                    operadores.push(c);
                } 
                else if (c == ')') 
                {
                    while (!operadores.isEmpty() && operadores.peek() != '(') 
                    {
                        terminos.add(operadores.pop().toString());
                    }
                    operadores.pop();
                } else if (esOperador(c)) 
                {
                    while (!operadores.isEmpty() && precedencia(operadores.peek()) >= precedencia(c)) 
                    {
                        terminos.add(operadores.pop().toString());
                    }
                    operadores.push(c);
                }
            }
        }

        if (numero.length() > 0) 
        {
            terminos.add(numero.toString());
        }

        while (!operadores.isEmpty()) 
        {
            terminos.add(operadores.pop().toString());
        }

        return terminos;
    }

    private boolean esNumero(String valor) 
    {
        try 
        {
            Double.parseDouble(valor);
            return true;
        } 
        catch (NumberFormatException e) 
        {
            return false;
        }
    }

    private boolean esOperador(char c) 
    {
        return c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '√';
    }

    private int precedencia(char operador) 
    {
        switch (operador) 
        {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            case '^':
            case '√':
                return 3;
        }
        return -1;
    }

    public static void main(String[] args) 
    {
        new Calculador_a();
    }
}
