package gui;
import main.VectoresLogica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;


public class VectoresR3 extends JFrame {
	double a, b, c, d, E, f, R3resSuma1, R3resSuma2, R3resSuma3, R3resResta1, R3resResta2, R3resResta3, R3resMxEscalar1, R3resMxEscalar2, R3resMxEscalar3, R3resProdE1, R3resProdE2, R3resProdE3, resultadoR3PV;
	int escalar = 0, segundotermino = 0, modoEscalar = 0, vaciar = 0, modoSuma = 0, modoResta = 0, modoNormal = 0, modoProdEscalar = 0, modoProdVectorial = 0, cont = 0;
	boolean capturandoSegundoVector, capturandoSegundoVector1;
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtNumero1;
	private JTextField txtNumero2;
	private JTextField txtEscalar;
	private JTextField txtNumero3;
	JPanel panelResultados = new JPanel();
	JPanel panelEscalar = new JPanel();
	JButton btnNegativePositive = new JButton("+/-");
	JButton btnDivideComponentes = new JButton("(a, b, c)");
	JButton btnMultiplicar = new JButton("X");
	JButton btnMultiplicarEscalar = new JButton("XE");
	JButton btnSuma = new JButton("+");
	JButton btnResta = new JButton("-");
	JButton btnResultadoFinal = new JButton("=");
	JButton btnDel = new JButton("DEL");
	JButton btnProdVectorial = new JButton("XV");
	
	/**
	 * Create the frame.
	 */
	public VectoresR3() {

		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 550);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);

		resultados();
		funciones();
		operaciones();
		titulo();
	}
	private void operaciones()
	{
		if(txtNumero1.getText().length() > -1 || txtNumero2.getText().length() > -1 || txtNumero3.getText().length() > -1 || txtEscalar.getText().length() > -1)
		{
			activarBotonesOperaciones();
		}	
		JPanel panelOperaciones = new JPanel();
		panelOperaciones.setBounds(10, 161, 414, 50);
		contentPane.add(panelOperaciones);
		
		btnMultiplicar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numeroingresado = txtNumero3.getText();
				double temp = Double.parseDouble(numeroingresado);
				c = temp;
				temp = 0;
				modoProdEscalar = 1;
				segundotermino = 0;
				txtNumero1.setText(null);
				txtNumero2.setText(null);
				txtNumero3.setText(null);
			}
		});
		panelOperaciones.setLayout(new GridLayout(1, 7, 0, 0));
		
		panelOperaciones.add(btnDel);
		btnDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)
		    {
				if(segundotermino == 0)
				{
					if(txtNumero1.getText().length() > 0)
			        {
			        	txtNumero1.setText(txtNumero1.getText().substring(0, txtNumero1.getText().length() - 1));
			        }

			        if(txtNumero1.getText().length() == 0)
			        {
			            desactivarBotonesOperaciones();
			        }
				}
				if(segundotermino == 1)
				{
					if(txtNumero2.getText().length() > 0)
			        {
			        	txtNumero2.setText(txtNumero2.getText().substring(0, txtNumero2.getText().length() - 1));
			        }

			        if(txtNumero2.getText().length() == 0)
			        {
			            desactivarBotonesOperaciones();
			        }
				}
				if(segundotermino == 2)
				{
					if(txtNumero3.getText().length() > 0)
			        {
			        	txtNumero3.setText(txtNumero3.getText().substring(0, txtNumero3.getText().length() - 1));
			        }

			        if(txtNumero3.getText().length() == 0)
			        {
			            desactivarBotonesOperaciones();
			        }
				}
				if(modoEscalar == 1)
				{
					if(txtEscalar.getText().length() > 0)
					{
						txtEscalar.setText(txtEscalar.getText().substring(0, txtEscalar.getText().length() - 1));
					}
					
					if(txtEscalar.getText().length() == 0)
			        {
			            desactivarBotonesOperaciones();
			        }
				}
				
				if(vaciar == 1)
				{
					txtNumero1.setText(null);
					txtNumero2.setText(null);
					txtNumero3.setText(null);
					txtEscalar.setText(null);
					escalar = 0;
					a = 0;
					b = 0;
					c = 0;
					d = 0;
					E = 0;
					f = 0;
					R3resSuma1 = 0;
					R3resSuma2 = 0;
					R3resSuma3 = 0;
					R3resResta1 = 0;
					R3resResta2 = 0;
					R3resResta3 = 0;
					R3resMxEscalar1 = 0;
					R3resMxEscalar2 = 0;
					R3resMxEscalar3 = 0;
					R3resProdE1 = 0;
					R3resProdE2 = 0;
					R3resProdE3 = 0;
					resultadoR3PV = 0;
					activarBotonesOperaciones();
					segundotermino = 0;
					vaciar = 0;
					btnNegativePositive.setEnabled(true);
					btnDivideComponentes.setEnabled(true);
					panelEscalar.setVisible(false);
					panelResultados.setVisible(true);
				}
		    }
		});
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numeroingresado = txtNumero3.getText();
				double temp = Double.parseDouble(numeroingresado);
				c = temp;
				temp = 0;
				modoSuma = 1;
				segundotermino = 0;
				txtNumero1.setText(null);
				txtNumero2.setText(null);
				txtNumero3.setText(null);
			}
		});
		
		panelOperaciones.add(btnSuma);
		
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numeroingresado = txtNumero3.getText();
				double temp = Double.parseDouble(numeroingresado);
				c = temp;
				temp = 0;
				modoResta = 1;
				segundotermino = 0;
				txtNumero1.setText(null);
				txtNumero2.setText(null);
				txtNumero3.setText(null);
			}
		});
		
		panelOperaciones.add(btnResta);
		
		btnResultadoFinal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(modoEscalar == 1)
				{
					String numeroingresado = txtEscalar.getText();
					int temp = Integer.parseInt(numeroingresado);
					escalar = temp;
					temp = 0;
					double[] resultados = new double[3];
		            VectoresLogica.R3MultEscalar(a, b, c, escalar, resultados);

		            R3resMxEscalar1 = resultados[0];
		            R3resMxEscalar2 = resultados[1];
		            R3resMxEscalar3 = resultados[2];
		            
					String tempRes = Double.toString(R3resMxEscalar1);
					String tempRes1 = Double.toString(R3resMxEscalar2);
					String tempRes2 = Double.toString(R3resMxEscalar3);
					panelEscalar.setVisible(false);
					panelResultados.setVisible(true);
					txtNumero1.setText(tempRes);
					txtNumero2.setText(tempRes1);
					txtNumero3.setText(tempRes2);
					tempRes = null;
					tempRes1 = null;
					tempRes2 = null;
					vaciar = 1;
					desactivarBotonesOperaciones();
				    btnDel.setEnabled(true);
				    modoEscalar = 0;
				}
				if(modoSuma == 1)
				{
					String numeroingresado = txtNumero3.getText();
					double temp = Double.parseDouble(numeroingresado);
					f = temp;
					temp = 0;
					double[] resultadosR3S = new double[3];
					VectoresLogica.R3suma(a, b, c, d, E, f, resultadosR3S);
					
					R3resSuma1 = resultadosR3S[0];
					R3resSuma2 = resultadosR3S[1];
					R3resSuma3 = resultadosR3S[2];
					
					String tempRes = Double.toString(R3resSuma1);
					String tempRes1 = Double.toString(R3resSuma2);
					String tempRes2 = Double.toString(R3resSuma3);
					txtNumero1.setText(tempRes);
					txtNumero2.setText(tempRes1);
					txtNumero3.setText(tempRes2);
					tempRes = null;
					tempRes1 = null;
					tempRes2 = null;
					vaciar = 1;
					desactivarBotonesOperaciones();
				    btnDel.setEnabled(true);
				    modoSuma = 0;
				}
				if(modoResta == 1)
				{
					String numeroingresado = txtNumero3.getText();
					double temp = Double.parseDouble(numeroingresado);
					f = temp;
					temp = 0;
					double[] resultadosR3R = new double[3];
					VectoresLogica.R3resta(a, b, c, d, E, f, resultadosR3R);
					
					R3resResta1 = resultadosR3R[0];
					R3resResta2 = resultadosR3R[1];
					R3resResta3 = resultadosR3R[2];
					
					String tempRes = Double.toString(R3resResta1);
					String tempRes1 = Double.toString(R3resResta2);
					String tempRes2 = Double.toString(R3resResta3);
					txtNumero1.setText(tempRes);
					txtNumero2.setText(tempRes1);
					txtNumero3.setText(tempRes2);
					tempRes = null;
					tempRes1 = null;
					tempRes2 = null;
					vaciar = 1;
					desactivarBotonesOperaciones();
				    btnDel.setEnabled(true);
				    modoResta = 0;
				}
				
				if(modoProdVectorial == 1)
				{
					String numeroingresado = txtNumero3.getText();
					double temp = Double.parseDouble(numeroingresado);
					f = temp;
					temp = 0;
					double[] resultado = new double[1];
					VectoresLogica.R3ProdVectorial(a, b, c, d, E, f, resultado);
					
					resultadoR3PV = resultado[0];
					
					String tempRes = Double.toString(resultadoR3PV);
					panelEscalar.setVisible(true);
					panelResultados.setVisible(false);
					txtEscalar.setText(tempRes);
					tempRes = null;
					vaciar = 1;
					desactivarBotonesOperaciones();
					btnDel.setEnabled(true);
					modoProdVectorial = 0;
				}
				
				if(modoProdEscalar == 1)
				{
					String numeroingresado = txtNumero3.getText();
					double temp = Double.parseDouble(numeroingresado);
					f = temp;
					temp = 0;
					double[] resultadosR3PE = new double[3];
					VectoresLogica.R3ProdEscalar(a, b, c, d, E, f, resultadosR3PE);
					
					R3resProdE1 = resultadosR3PE[0];
					R3resProdE2 = resultadosR3PE[1];
					R3resProdE3 = resultadosR3PE[2];
					
					String tempRes = Double.toString(R3resProdE1);
					String tempRes1 = Double.toString(R3resProdE2);
					String tempRes2 = Double.toString(R3resProdE3);
					txtNumero1.setText(tempRes);
					txtNumero2.setText(tempRes1);
					txtNumero3.setText(tempRes2);
					tempRes = null;
					tempRes1 = null;
					tempRes2 = null;
					vaciar = 1;
					desactivarBotonesOperaciones();
					btnDel.setEnabled(true);
					modoProdEscalar = 0;
				}
			}
		});
		panelOperaciones.add(btnResultadoFinal);
		
		panelOperaciones.add(btnMultiplicar);
		
		panelOperaciones.add(btnMultiplicarEscalar);
		btnMultiplicarEscalar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numeroingresado = txtNumero3.getText();
				double temp = Double.parseDouble(numeroingresado);
				c = temp;
				temp = 0;
				panelResultados.setVisible(false);
				panelEscalar.setVisible(true);
				modoEscalar = 1;
				btnDivideComponentes.setEnabled(false);
				txtEscalar.setText(null);
			}
		});
		
		btnProdVectorial.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String numeroingresado = txtNumero3.getText();
				double temp = Double.parseDouble(numeroingresado);
				c = temp;
				modoProdVectorial = 1;
				segundotermino = 0;
				txtNumero1.setText(null);
				txtNumero2.setText(null);
				txtNumero3.setText(null);
			}
		});
		btnProdVectorial.setFont(new Font("Tahoma", Font.PLAIN, 11));
		panelOperaciones.add(btnProdVectorial);
	}
	private void resultados()
	{
		
		panelEscalar.setBounds(10, 44, 414, 106);
		panelEscalar.setVisible(false);
		
		panelResultados.setBounds(0, 44, 434, 106);
		contentPane.add(panelResultados);
		panelResultados.setLayout(null);
		
		txtNumero1 = new JTextField();
		txtNumero1.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero1.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero1.setEditable(false);
		txtNumero1.setBounds(43, 11, 82, 84);
		panelResultados.add(txtNumero1);
		txtNumero1.setColumns(10);
		
		txtNumero2 = new JTextField();
		txtNumero2.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero2.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero2.setEditable(false);
		txtNumero2.setColumns(10);
		txtNumero2.setBounds(180, 11, 82, 84);
		panelResultados.add(txtNumero2);
		
		JLabel lblParentesis = new JLabel("(");
		lblParentesis.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblParentesis.setBounds(10, 29, 46, 43);
		panelResultados.add(lblParentesis);
		
		JLabel lblParentesis2 = new JLabel(")");
		lblParentesis2.setHorizontalAlignment(SwingConstants.RIGHT);
		lblParentesis2.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblParentesis2.setBounds(378, 29, 46, 43);
		panelResultados.add(lblParentesis2);
		
		JLabel lblComa = new JLabel(",");
		lblComa.setHorizontalAlignment(SwingConstants.CENTER);
		lblComa.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblComa.setBounds(135, 29, 46, 43);
		panelResultados.add(lblComa);
		
		txtNumero3 = new JTextField();
		txtNumero3.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero3.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtNumero3.setEditable(false);
		txtNumero3.setColumns(10);
		txtNumero3.setBounds(309, 11, 82, 84);
		panelResultados.add(txtNumero3);
		
		JLabel lblComa_1 = new JLabel(",");
		lblComa_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblComa_1.setFont(new Font("Segoe UI", Font.PLAIN, 30));
		lblComa_1.setBounds(264, 29, 46, 43);
		panelResultados.add(lblComa_1);
		
		panelEscalar.setLayout(null);
		contentPane.add(panelEscalar);
		txtEscalar = new JTextField();
		txtEscalar.setHorizontalAlignment(SwingConstants.CENTER);
		txtEscalar.setFont(new Font("Segoe UI", Font.PLAIN, 25));
		txtEscalar.setEditable(false);
		txtEscalar.setBounds(157, 11, 90, 90);
		panelEscalar.add(txtEscalar);
		txtEscalar.setColumns(10);
		
	}
	
	private void funciones()
	{
		if(txtNumero1.getText().length() > 0 || txtNumero2.getText().length() > 0 || txtNumero3.getText().length() > 0 || txtEscalar.getText().length() > 0)
		{
			activarBotonesOperaciones();
		}
		JPanel panelFunciones = new JPanel();
		panelFunciones.setBounds(10, 225, 414, 268);
		contentPane.add(panelFunciones);
		panelFunciones.setLayout(new GridLayout(4, 3, 0, 0));
		
		JButton btnNum7 = new JButton("7");
		panelFunciones.add(btnNum7);
		insertarnum(btnNum7);
		JButton btnNum8 = new JButton("8");
		panelFunciones.add(btnNum8);
		insertarnum(btnNum8);
		
		JButton btnNum9 = new JButton("9");
		panelFunciones.add(btnNum9);
		insertarnum(btnNum9);
		
		JButton btnNum4 = new JButton("4");
		panelFunciones.add(btnNum4);
		insertarnum(btnNum4);
		
		JButton btnNum5 = new JButton("5");
		panelFunciones.add(btnNum5);
		insertarnum(btnNum5);
		
		JButton btnNum6 = new JButton("6");
		panelFunciones.add(btnNum6);
		insertarnum(btnNum6);
		
		JButton btnNum1 = new JButton("1");
		panelFunciones.add(btnNum1);
		insertarnum(btnNum1);		
		
		JButton btnNum2 = new JButton("2");
		panelFunciones.add(btnNum2);
		insertarnum(btnNum2);
		
		JButton btnNum3 = new JButton("3");
		panelFunciones.add(btnNum3);
		insertarnum(btnNum3);
		
		btnNegativePositive.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(segundotermino == 0)
				{
					String texto1 = txtNumero1.getText();
			        double numero1 = Double.parseDouble(texto1);
			        numero1 = -numero1;
			        txtNumero1.setText(String.valueOf(numero1));
				}
				if(segundotermino == 1)
				{
					String texto1 = txtNumero2.getText();
			        double numero1 = Double.parseDouble(texto1);
			        numero1 = -numero1;
			        txtNumero2.setText(String.valueOf(numero1));
				}
				if(segundotermino == 2)
				{
					String texto1 = txtNumero3.getText();
					double numero1 = Double.parseDouble(texto1);
					numero1 = -numero1;
					txtNumero3.setText(String.valueOf(numero1));
				}
				if(modoEscalar == 1)
				{
					String texto1 = txtEscalar.getText();
			        double numero1 = Double.parseDouble(texto1);
			        numero1 = -numero1;
			        txtEscalar.setText(String.valueOf(numero1));
			        modoEscalar = 0;
				}
			}
		});
		
		panelFunciones.add(btnNegativePositive);
		
		JButton btnNum0 = new JButton("0");
		panelFunciones.add(btnNum0);
		insertarnum(btnNum0);
		
		panelFunciones.add(btnDivideComponentes);
		btnDivideComponentes.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				boolean capturandoPrimerVector = true;
				cont++;

		        // Si estamos en modo de alguna operación, cambiamos al segundo vector
		        if(modoSuma == 1 || modoResta == 1 || modoProdEscalar == 1 || modoProdVectorial == 1)
		        {
		            modoNormal = 0;
		            if (capturandoPrimerVector)
		            {
		                String numeroingresado = txtNumero1.getText();
		                double temp = Double.parseDouble(numeroingresado);
		                d = temp;
		                capturandoSegundoVector = true;
		                capturandoPrimerVector = false; // Terminamos de capturar el primer vector
		            }
		        }
		        else
		        {
		            modoNormal = 1; // Modo normal cuando no se está haciendo ninguna cuenta
		        }

		        // Capturamos el segundo componente del segundo vector
		        if(capturandoSegundoVector && !capturandoPrimerVector && cont == 2)
		        {
		            String numeroingresado = txtNumero2.getText();
		            double temp = Double.parseDouble(numeroingresado);
		            E = temp;
		            capturandoSegundoVector = false;
		            cont = 0; // Reiniciamos el contador después de capturar el segundo componente
		        }

		        // Capturamos el primer vector
		        if(modoNormal == 1 && capturandoPrimerVector)
		        {
		            if (cont == 1)
		            { // Primer componente del primer vector
		                String numeroingresado = txtNumero1.getText();
		                double temp = Double.parseDouble(numeroingresado);
		                a = temp;
		            }
		            else if (cont == 2)
		            { // Segundo componente del primer vector
		                String numeroingresado = txtNumero2.getText();
		                double temp = Double.parseDouble(numeroingresado);
		                b = temp;
		                capturandoPrimerVector = false; // Terminamos de capturar el primer vector
		                cont = 0; // Reiniciamos el contador después de capturar ambos componentes del primer vector
		            }
		        }
				//A partir de acá la lógica de esto no interviene en lo de arriba
				if(segundotermino == 0)
				{
					segundotermino = 1;
				}
				
				else if(segundotermino == 1)
		        {
		        	segundotermino = 2;
		        }
				
				else if(segundotermino == 2)
				{
					segundotermino = 0;
				}
			}
		});
		
	}
	private void titulo()
	{
		JPanel panelTitulo = new JPanel();
		panelTitulo.setBounds(0, 0, 434, 39);
		contentPane.add(panelTitulo);
		panelTitulo.setLayout(null);
		
		JLabel lblTitulo = new JLabel("Calculadora Vectores R3");
		lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
		lblTitulo.setBounds(10, 11, 414, 23);
		panelTitulo.add(lblTitulo);
	}
	private void insertarnum(JButton boton)
	{
		boton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(txtNumero1.getText().length() > 0 || txtNumero2.getText().length() > 0 || txtEscalar.getText().length() > 0)
				{
					activarBotonesOperaciones();
				}
				if(segundotermino == 0)
				{
					btnNegativePositive.setEnabled(true);
					btnDivideComponentes.setEnabled(true);
					String ingresenumero = txtNumero1.getText() + boton.getText();
					txtNumero1.setText(ingresenumero);
					ingresenumero = null;
				}
				
				if(segundotermino == 1)
				{
					btnNegativePositive.setEnabled(true);
					btnDivideComponentes.setEnabled(true);
					String ingresenumero1 = txtNumero2.getText() + boton.getText();
					txtNumero2.setText(ingresenumero1);
					ingresenumero1 = null;
				}
				
				if(segundotermino == 2)
				{
					btnNegativePositive.setEnabled(true);
					btnDivideComponentes.setEnabled(true);
					String ingresenumero3 = txtNumero3.getText() + boton.getText();
					txtNumero3.setText(ingresenumero3);
					ingresenumero3 = null;
				}
				
				if(modoEscalar == 1)
				{
					btnDivideComponentes.setEnabled(false);
					String ingresenumero2 = txtEscalar.getText() + boton.getText();
					txtEscalar.setText(ingresenumero2);
					ingresenumero2 = null;
				}
			}
		});
	}
	private void desactivarBotonesOperaciones() {
	    btnMultiplicar.setEnabled(false);
	    btnSuma.setEnabled(false);
	    btnResta.setEnabled(false);
	    btnMultiplicarEscalar.setEnabled(false);
	    btnResultadoFinal.setEnabled(false);
	    btnDel.setEnabled(false);
	    btnProdVectorial.setEnabled(false);
	}

	private void activarBotonesOperaciones() {
	    btnMultiplicar.setEnabled(true);
	    btnSuma.setEnabled(true);
	    btnResta.setEnabled(true);
	    btnMultiplicarEscalar.setEnabled(true);
	    btnResultadoFinal.setEnabled(true);
	    btnDel.setEnabled(true);
	    btnProdVectorial.setEnabled(true);
	}
}