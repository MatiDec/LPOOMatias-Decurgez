package gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class VectoresMain extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VectoresMain frame = new VectoresMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VectoresMain() {
		VectoresR2 ventanaR2 = new VectoresR2();
		VectoresR3 ventanaR3 = new VectoresR3();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panelTitulo = new JPanel();
		panelTitulo.setBounds(10, 11, 414, 61);
		contentPane.add(panelTitulo);
		
		JLabel lblTitulo = new JLabel("Calculadora de Vectores");
		lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 30));
		panelTitulo.add(lblTitulo);
		
		JPanel panelSeleccion = new JPanel();
		panelSeleccion.setBounds(10, 83, 414, 317);
		contentPane.add(panelSeleccion);
		panelSeleccion.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Seleccione el modo de la calculadora");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 11, 394, 27);
		panelSeleccion.add(lblNewLabel);
		
		JButton btnR2 = new JButton("R2");
		btnR2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				ventanaR2.setVisible(true);
				VectoresMain frame = new VectoresMain();
				frame.setVisible(false);
			}
		});
		btnR2.setBounds(10, 120, 184, 100);
		panelSeleccion.add(btnR2);
		
		JButton btnR3 = new JButton("R3");
		btnR3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ventanaR3.setVisible(true);
				VectoresMain frame = new VectoresMain();
				frame.setVisible(false);
			}
		});
		btnR3.setBounds(220, 120, 184, 100);
		panelSeleccion.add(btnR3);
	}
}
